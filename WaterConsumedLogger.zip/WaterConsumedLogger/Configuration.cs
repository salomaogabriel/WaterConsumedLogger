﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterConsumedLogger
{
    public class Configuration
    {
        public string FileName { get; set; }
        public int AmountPerBottleDefault { get; set; }
    }
}
